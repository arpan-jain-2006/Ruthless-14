document.addEventListener("DOMContentLoaded", function () {
    // Function to store form data
    function saveDataToLocalStorage(formId, storageKey) {
        const form = document.getElementById(formId);
        form.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent page reload

            // Collect data
            const formData = {
                name: form.querySelector('input[type="text"]').value,
                bloodGroup: form.querySelector('select').value,
                country: form.querySelectorAll('select')[1].value,
                state: form.querySelectorAll('select')[2].value,
                contact: form.querySelector('input[type="tel"]').value,
                email: form.querySelector('input[type="email"]')?.value || "", // Only for donor form
            };

            // Get existing data from localStorage
            let existingData = JSON.parse(localStorage.getItem(storageKey)) || [];
            existingData.push(formData);

            // Save back to localStorage
            localStorage.setItem(storageKey, JSON.stringify(existingData));

            alert("Data saved successfully!");
            form.reset(); // Clear the form
        });
    }

    // Save donor and recipient data
    saveDataToLocalStorage("donor-form", "donors");
    saveDataToLocalStorage("recipient-form", "recipients");
});
function displayData(storageKey, containerId) {
    const container = document.getElementById(containerId);
    const data = JSON.parse(localStorage.getItem(storageKey)) || [];

    container.innerHTML = ""; // Clear old data
    data.forEach((entry, index) => {
        const div = document.createElement("div");
        div.classList.add("entry");
        div.innerHTML = `
            <p><strong>${entry.name}</strong> (${entry.bloodGroup})</p>
            <p>Location: ${entry.state}, ${entry.country}</p>
            <p>Contact: ${entry.contact}</p>
        `;
        container.appendChild(div);
    });
}

// Call these functions where needed
displayData("donors", "donor-container");
displayData("recipients", "recipient-container");






document.addEventListener("DOMContentLoaded", function () {
    const donorForm = document.getElementById("donor-form");
    const recipientForm = document.getElementById("recipient-form");

    // Function to save data to localStorage
    function saveToLocalStorage(key, data) {
        let existingData = JSON.parse(localStorage.getItem(key)) || [];
        existingData.push(data);
        localStorage.setItem(key, JSON.stringify(existingData));
    }

    // Function to handle donor form submission
    if (donorForm) {
        donorForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("name")?.value.trim();
            const bloodGroup = document.getElementById("blood-group")?.value;
            const country = document.getElementById("country")?.value;
            const state = document.getElementById("state")?.value;
            const email = document.getElementById("email")?.value.trim();
            const phone = document.getElementById("phone")?.value.trim();

            if (!name || !bloodGroup || !country || !state || !email || !phone) {
                alert("Please fill in all donor fields.");
                return;
            }

            const donorData = { name, bloodGroup, country, state, email, phone };
            saveToLocalStorage("donors", donorData);

            donorForm.reset(); // Clear form fields
        });
    }

    // Function to handle recipient form submission
    if (recipientForm) {
        recipientForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("recipient-name")?.value.trim();
            const bloodGroup = document.getElementById("recipient-blood-group")?.value;
            const country = document.getElementById("recipient-country")?.value;
            const state = document.getElementById("recipient-state")?.value;
            const contact = document.getElementById("recipient-contact")?.value.trim();

            if (!name || !bloodGroup || !country || !state || !contact) {
                alert("Please fill in all recipient fields.");
                return;
            }

            const recipientData = { name, bloodGroup, country, state, contact };
            saveToLocalStorage("recipients", recipientData);

            recipientForm.reset(); // Clear form fields
        });
    }
});